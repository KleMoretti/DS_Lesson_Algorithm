package com.indi.llk.Interface_Controller;

import com.indi.llk.Game_Core_Controller.GameTimer;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.security.cert.PolicyNode;

public class Level_Mode_Controller {
    @FXML
    private AnchorPane ID_LEVEL_GAME_GROUND;
    private GameTimer gameTimer;
    private boolean isGameStarted = false;
    private Label timerLabel;
    private Label scoreLabel;
    private Label levelLabel;
    private int currentLevel = 1;
    private int currentScore = 0;
    private int timeLimit=300;

    public void initialize(){
        System.out.println("Level Mode Controller Initialized");

        createTimerLabel();
        createScoreLabel();
        createLevelLabel();

    }

    private void createLevelLabel() {
        levelLabel = new Label("Level: " + currentLevel);

        ID_LEVEL_GAME_GROUND.getChildren().add(levelLabel);

    }

    private void createScoreLabel() {

    }

    private void createTimerLabel() {
        timerLabel = new Label(String.format("%02d:%02d", timeLimit/60, timeLimit%60));
        timerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        timerLabel.setTextFill(Color.WHITE);
        timerLabel.setStyle("-fx-background-color: rgba(0,0,0,0.4); -fx-padding: 5px 10px; -fx-background-radius: 5px;");
        timerLabel.setAlignment(Pos.CENTER);
        timerLabel.setPrefWidth(80);

        AnchorPane.setTopAnchor(timerLabel, 40.0);
        AnchorPane.setRightAnchor(timerLabel, 450.0);

        timerLabel.setVisible(false);

        ID_LEVEL_GAME_GROUND.getChildren().add(timerLabel);

        gameTimer = new GameTimer(timerLabel);
    }





}
